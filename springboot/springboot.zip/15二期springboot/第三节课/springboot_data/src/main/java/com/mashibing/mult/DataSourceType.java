package com.mashibing.mult;

public enum DataSourceType {
    REMOTE,
    LOCAL
}